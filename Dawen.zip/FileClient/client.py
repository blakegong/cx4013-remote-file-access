import socket
import util
#socket setting
server_IP = '192.168.1.18'
server_PORT = 9800
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)

#send operations
operation = {'op':0, 'offset':1, 'len':5, 'filename': 'readme.txt', 'sem':0}
operation = util.marshall(operation);
sock.sendto(operation, (server_IP, server_PORT))

#receive data
data, address = sock.recvfrom(1024)
response = util.unmarshall(data)
print response
sock.close()
